"""
inference.py
─────────────────────────────────────────────────────────────────────────────
Full-scene inference using the best-performing SVM model.

Workflow:
  1. Train SVM on the complete labeled dataset (all 8108 samples).
  2. Read all Sentinel-2 band rasters and build a pixel matrix.
  3. Predict land cover class for every valid pixel.
  4. Write the result as a georeferenced GeoTIFF.
  5. Print area statistics per class.

Output:
  predicted_landcover.tif  — single-band categorical raster
                             1 = Built-up | 2 = Soil | 3 = Vegetation | 4 = Water

Usage:
  python inference.py
"""

import numpy as np
import pandas as pd
import rasterio
from rasterio.transform import from_bounds
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, StandardScaler

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

DATASET_TSV = "training_dataset.tsv"

BAND_FILES = {
    "B2":  "B2.tif",
    "B3":  "B3.tif",
    "B4":  "B4.tif",
    "B5":  "B5.tif",
    "B6":  "B6.tif",
    "B7":  "B7.tif",
    "B8":  "B8.tif",
    "B8A": "B8A.tif",
    "B11": "B11.tif",
    "B12": "B12.tif",
}

BAND_COLS = list(BAND_FILES.keys())

# Integer codes assigned to each class in the output raster
CLASS_CODES = {
    "Built-up":   1,
    "Soil":       2,
    "Vegetation": 3,
    "Water":      4,
}

# Colors for the thematic map preview
CLASS_COLORS = {
    1: "#d9534f",   # Built-up  — red
    2: "#c8a96e",   # Soil      — tan
    3: "#5cb85c",   # Vegetation — green
    4: "#5bc0de",   # Water     — blue
}

OUTPUT_TIFF = "predicted_landcover.tif"
OUTPUT_MAP  = "docs/figures/thematic_map.png"

# ─────────────────────────────────────────────
# 1. TRAIN SVM ON FULL DATASET
# ─────────────────────────────────────────────

print("Loading training dataset...")
df = pd.read_csv(DATASET_TSV, sep="\t")
print(f"  {len(df)} samples — classes: {df['label'].value_counts().to_dict()}")

X_all = df[BAND_COLS].values
y_all = df["label"].values

le = LabelEncoder()
y_encoded = le.fit_transform(y_all)
print(f"  Label encoding: {dict(zip(le.classes_, le.transform(le.classes_)))}")

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_all)

print("Training SVM on full dataset (this may take a minute)...")
svm = SVC(kernel="rbf", C=10, gamma="scale", random_state=42)
svm.fit(X_scaled, y_encoded)
print("  Done.")

# ─────────────────────────────────────────────
# 2. LOAD RASTER STACK
# ─────────────────────────────────────────────

print("\nReading raster bands...")

# Use the first band to get spatial metadata
with rasterio.open(BAND_FILES["B2"]) as ref:
    profile = ref.profile.copy()
    height  = ref.height
    width   = ref.width
    crs     = ref.crs
    transform = ref.transform
    nodata  = ref.nodata

print(f"  Scene size: {width} x {height} pixels  |  CRS: {crs.to_string()}")

# Stack all bands into shape (n_bands, height, width)
band_stack = np.zeros((len(BAND_COLS), height, width), dtype=np.float32)

for i, band_name in enumerate(BAND_COLS):
    with rasterio.open(BAND_FILES[band_name]) as src:
        band_stack[i] = src.read(1).astype(np.float32)

print("  Band stack ready.")

# ─────────────────────────────────────────────
# 3. PREDICT IN ROW CHUNKS (memory-safe)
# ─────────────────────────────────────────────

CHUNK_ROWS = 200   # process this many rows at a time (~200 MB peak per chunk)

out_array = np.zeros((height, width), dtype=np.uint8)   # 0 = nodata
nodata_val = nodata if nodata is not None else 0

print(f"\nRunning inference in chunks of {CHUNK_ROWS} rows...")

for row_start in range(0, height, CHUNK_ROWS):
    row_end = min(row_start + CHUNK_ROWS, height)
    chunk = band_stack[:, row_start:row_end, :]           # (n_bands, chunk_h, w)
    chunk_h = row_end - row_start

    X_chunk = chunk.reshape(len(BAND_COLS), chunk_h * width).T   # (n_px, n_bands)

    # Valid-pixel mask within this chunk
    valid = ~np.all(X_chunk == nodata_val, axis=1)

    if valid.any():
        X_valid_scaled = scaler.transform(X_chunk[valid])
        y_enc = svm.predict(X_valid_scaled)
        y_labels = le.inverse_transform(y_enc)
        y_codes  = np.array([CLASS_CODES[l] for l in y_labels], dtype=np.uint8)

        out_chunk = np.zeros(chunk_h * width, dtype=np.uint8)
        out_chunk[valid] = y_codes
        out_array[row_start:row_end, :] = out_chunk.reshape(chunk_h, width)

    if (row_start // CHUNK_ROWS) % 10 == 0:
        pct = row_end / height * 100
        print(f"  {pct:.0f}%  (rows {row_start}–{row_end})")

print("  Inference complete.")

# ─────────────────────────────────────────────
# 5. WRITE GEOTIFF
# ─────────────────────────────────────────────
n_pixels = height * width

profile.update(
    dtype=rasterio.uint8,
    count=1,
    nodata=0,
    compress="lzw",
)
# Remove multi-band keys that don't apply
for key in ["photometric"]:
    profile.pop(key, None)

with rasterio.open(OUTPUT_TIFF, "w", **profile) as dst:
    dst.write(out_array, 1)

print(f"\nGeoTIFF saved: {OUTPUT_TIFF}")

# ─────────────────────────────────────────────
# 6. AREA STATISTICS
# ─────────────────────────────────────────────

# Pixel size in metres (assumes a projected CRS such as UTM)
pixel_area_m2 = abs(transform.a * transform.e)   # |dx * dy|
pixel_area_km2 = pixel_area_m2 / 1_000_000
pixel_area_ha  = pixel_area_m2 / 10_000

print("\n== Area per land cover class ==========================")
print(f"  Pixel resolution: {abs(transform.a):.1f} m  -> {pixel_area_ha:.4f} ha/pixel")
print(f"{'Class':<15} {'Pixels':>10} {'Area (ha)':>12} {'Area (km2)':>12}")
print("-" * 55)

code_to_name = {v: k for k, v in CLASS_CODES.items()}
for code in sorted(CLASS_CODES.values()):
    count = int(np.sum(out_array == code))
    area_ha  = count * pixel_area_ha
    area_km2 = count * pixel_area_km2
    name = code_to_name[code]
    print(f"  {name:<13} {count:>10,} {area_ha:>12.1f} {area_km2:>12.3f}")

total_valid = int(np.sum(out_array > 0))
print("-" * 55)
print(f"  {'TOTAL':<13} {total_valid:>10,} {total_valid*pixel_area_ha:>12.1f} {total_valid*pixel_area_km2:>12.3f}")

# ─────────────────────────────────────────────
# 7. SAVE THEMATIC MAP PREVIEW
# ─────────────────────────────────────────────

print(f"\nGenerating thematic map preview → {OUTPUT_MAP}")

# Build RGB image for display
rgb = np.zeros((height, width, 3), dtype=np.uint8)
for code, hex_color in CLASS_COLORS.items():
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    mask_class = out_array == code
    rgb[mask_class] = [r, g, b]

fig, ax = plt.subplots(figsize=(10, 8))
ax.imshow(rgb)
ax.set_title("Predicted Land Cover — Kakhovka Post-Event (SVM)", fontsize=13)
ax.axis("off")

patches = [
    mpatches.Patch(color=CLASS_COLORS[code], label=code_to_name[code])
    for code in sorted(CLASS_CODES.values())
]
ax.legend(handles=patches, loc="lower right", fontsize=10, framealpha=0.85)

plt.tight_layout()
plt.savefig(OUTPUT_MAP, dpi=150, bbox_inches="tight")
plt.show()
print(f"Thematic map saved: {OUTPUT_MAP}")
